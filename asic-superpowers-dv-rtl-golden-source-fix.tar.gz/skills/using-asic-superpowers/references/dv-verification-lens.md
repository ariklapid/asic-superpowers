# DV Verification Lens

Use for UVM, assertions, functional coverage, scoreboards, monitors, reference models, and regression debug.

## Golden Source Discipline

- DV intent comes from the architectural spec, design intent, verification plan, or explicit owner decision.
- RTL and waveforms show current DUT behavior; they are evidence for debug, not the source of expected behavior.
- A scoreboard/reference-model/checker/assertion should not be changed to duplicate RTL implementation unless spec evidence says the RTL behavior is intended.
- For RTL/DV mismatches, classify the outcome as RTL bug, DV bug, configuration/test issue, or spec gap. If intent is unclear, stop at "spec gap" and point to the needed owner/spec decision.
- If a temporary DV alignment is needed to unblock debug, label it as a workaround and keep the unresolved spec/intent question visible.

## Check

- Objective IDs map to tests, assertions, coverage, or review checks.
- Failing behavior is reproducible by test/seed or represented by a concrete log/waveform/report.
- Monitors sample at protocol-valid points and handle reset/error cases.
- Scoreboards compare the right abstraction level and preserve ordering assumptions.
- Reference models encode intended behavior, not current DUT behavior by accident.
- Assertions have clear clocks, reset disable conditions, antecedents, and non-vacuity considerations.
- Coverage bins map to real verification intent and avoid meaningless toggle-style closure.
- Regression scope is stated: targeted test, smoke, block regression, nightly, or unavailable.

## Do Not Claim

- Coverage closure without report evidence and exclusions/waivers.
- Assertion proof without formal/simulation assertion evidence.
- Bug fixed without the original failing test/seed or equivalent reproduction passing.
- DUT correctness when only the testbench was changed.
- DV correctness when the only evidence is "it now matches RTL."
